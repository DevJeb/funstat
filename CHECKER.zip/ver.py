import os
import asyncio
from telethon import TelegramClient, events
from telethon.sessions import StringSession

async def process_session(session_file):
    client = None
    try:
        # Подключаемся используя файл сессии
        client = TelegramClient(session_file, API_ID, API_HASH)
        await client.connect()
        
        if not await client.is_user_authorized():
            print(f"Сессия {session_file} не авторизована, пропускаем...")
            return False
        
        me = await client.get_me()
        print(f"\nУспешная авторизация в аккаунте {me.phone} (сессия: {session_file})")
        
        @client.on(events.NewMessage(from_users=777000))
        async def handler(event):
            msg = event.message
            if msg.reply_markup:
                for row in msg.reply_markup.rows:
                    for button in row.buttons:
                        if button.text.lower() in ["принять", "confirm"]:
                            print(f"Нажимаем кнопку '{button.text}' в аккаунте {me.phone}")
                            await msg.click(text=button.text)
                            return True  # Нажали кнопку, можно переходить к следующему аккаунту
        
        # Ждем сообщения от 777000 с таймаутом
        try:
            await asyncio.wait_for(client.run_until_disconnected(), timeout=30)
        except asyncio.TimeoutError:
            print(f"Таймаут ожидания сообщения для {me.phone}")
        
        return True
    
    except Exception as e:
        print(f"Ошибка при обработке сессии {session_file}: {str(e)}")
        return False
    finally:
        if client:
            await client.disconnect()

def find_session_files():
    session_files = []
    for root, _, files in os.walk("."):
        for file in files:
            if file.endswith(".session"):
                session_files.append(os.path.join(root, file))
    return session_files

async def main():
    session_files = find_session_files()
    if not session_files:
        print("Не найдено файлов сессий (.session) в текущей директории и подпапках")
        return
    
    print(f"Найдено {len(session_files)} файлов сессий. Начинаем обработку...")
    
    for session_file in session_files:
        input("Запускать?")
        print(f"\nОбрабатываем сессию: {session_file}")
        result = await process_session(session_file)
        if result:  # Если нажали кнопку, переходим к следующему аккаунту
            continue

# Конфигурация (замените на свои значения)
API_ID = 13529272  # Ваш API ID
API_HASH = '061e06eb472e220e6639bb764000e195'  # Ваш API Hash

if __name__ == '__main__':
    asyncio.run(main())
