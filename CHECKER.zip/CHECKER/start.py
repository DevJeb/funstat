import os
import subprocess
import sys

API_KEYS = [
    "AHUQDN4TWLA2FMQAAAAFD4VJBEPQ6EETRC7ABUX5LJFUNTUEXXPMIP3LQYP5BKRDQROXARI",
    "AGAAQMVUZT5KYQQAAAAFZNNRNLFYBICC7GPH5P6ON675LEKGSAW6ILXJLNBGWCOTVZRCOLA",
    "AEEPX4IKTP3KGRQAAAAAEXUPVWU6D3AXHMB26ZQAPMO34OA6SKR3AVH5IZR6AYY5WGBGLLY",
    "AECSCF5RUXIORHYAAAAKK7ZZWC7TB4S6SSKNWV4QG2W7KYB4AZP4JYDXVFP4IZGR4CXOTUY",
    "AHYTHTZKAHHJR5AAAAAORSBEP6LMR7S32IDEDHLFUIGMK7K5CTEXOSPL2QDEY2BUZ5TLXRA",
    "AG5U6QEJHT6F5HYAAAAFONWMATI75RLGIFOFKL23GUHJOQUD75OJN7W2YQWTL7JHOHODR7A",
    "AGRSJUTPALIEUZAAAAAAJ6Z64TTH7UL3NMF57RBPKWB45OGJCTEPAFOI3HCINH7OMZ5IBRA",
    "AFKO5IF2HCEN36QAAAAEOY7XBXF3YBFG6RCPBCZMQSFKQBDY7JW4LDYG3I337VK375QFNNA",
    "AHCJWFMFCFAWJEIAAAAETOA47CHSDFSSZLLVWD5LFV4XPP7LRQYQMVR4XNB6AU6LNHKRL3A",
    "AFXOY5ZBDZ2APUAAAAAMNJDEYBFFMUAQSNK3XVK2HH7LYQ7GRHZTMHTO3RJMD6DMKWZWERQ",
    "AGR46RDUNWHDONYAAAAH2QXPFBFD5JGJHGZTKHFXJY5HKEM54QGYNHCEPDIZCPKODZ5R6AQ",
    "AFPA2RWH7M4PZRAAAAAKIJ3CGSDNHYTJHXCOSAHWR4LSXXNSUDBFZGCZUMJSMKIPATBDMLY",
    "AEVV3KAS5D3FDGYAAAAFCOBR5QMKSP6DUXZKWY7JPHFSMZJCENQL4ZXBZIPOZ4KJKR4XNUA"
]

def split_keys(keys):
    """Делит массив ключей на две равные части"""
    mid = len(keys) // 2
    return keys[:mid], keys[mid:]

def run_in_screen(part, keys):
    """Запускает скрипт в screen с переданными ключами"""
    keys_str = " ".join(keys)
    screen_name = f"bot_part_{part}"
    command = f"screen -dmS {screen_name} python3 new_checker.py \"{keys_str}\""
    subprocess.run(command, shell=True, check=True)
    print(f"Запущен screen '{screen_name}' с {len(keys)} ключами")
    print(command)
if __name__ == "__main__":
    part1, part2 = split_keys(API_KEYS)
    
    # Запускаем две части в отдельных screen сессиях
    run_in_screen(1, part1)
    run_in_screen(2, part2)
    
    print("\nКоманды для управления screen сессиями:")
    print("screen -r bot_part_1  # Подключиться к первой части")
    print("screen -r bot_part_2  # Подключиться ко второй части")
    print("screen -ls           # Показать все активные сессии")
