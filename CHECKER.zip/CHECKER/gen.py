from itertools import product
with open("bip39.txt", "r") as f:
    words = f.read().split(" ")
length = 24  # длина комбинации
i = 0
temp=[]
for combo in product(words, repeat=length):
    temp.append(" ".join(combo))
    i+=1
    if i == 20:
        with open("seed_phrases.txt", "a+") as f:
            f.write("\n".join(temp))
        temp,i=[],0