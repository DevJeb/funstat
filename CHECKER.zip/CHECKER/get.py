from bs4 import BeautifulSoup
import requests, re

url = "https://tonviewer.com/EQCph-cHE7TuhsxJ8Bp9zMR4OM2LKdQe-74XELGYvw65u0Ud"  # Замените на нужный URL

# Загружаем страницу
response = requests.get(url)
if response.status_code != 200:
    print("Ошибка загрузки страницы")
    exit()

# Парсим HTML
soup = BeautifulSoup(response.text, 'html.parser')

# 1. Находим div, где есть текст "Balance"
balance_div = soup.find(lambda tag: tag.name == 'div' and tag.get_text(strip=True) == "Balance")

ton_div = balance_div.find_next(lambda tag: tag.name == 'div' and "TON" in tag.get_text())

if ton_div:
    ton_match = re.search(r"(\d+\.\d+)", ton_div.get_text(strip=True))
    if ton_match:
        print(float(ton_match.group(1)))