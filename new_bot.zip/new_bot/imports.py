import string

import os, urllib.parse, logging, json, asyncio, telethon, sys, socks, random, requests, process, subprocess, re, mimetypes, prob, gen
from telethon import TelegramClient, events, functions, connection, Button
from telethon.tl.types import PeerChannel, PeerChat, PeerUser, InputPeerUser
from telethon import errors
from datetime import datetime
from telethon.sessions import StringSession
