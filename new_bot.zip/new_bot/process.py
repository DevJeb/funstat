from imports import *
async def take(client: telethon.TelegramClient, event: telethon.events, _list: str, chat: int, phone:str):    
    dbs = str(event.raw_text).lower()
    if event.sender_id == (await client.get_me()).id:
        async def wait_for_code():
            future = asyncio.Future()  

            async def handler(event):
                if event.sender_id == 777000:
                    code = re.search(r'Код для входа в Telegram:\s*(\d+)', str(event.raw_text))
                    code = code.group(1)
                    future.set_result(code)
                    print(code)  
                    await client.delete_messages(event.chat_id, event.id)
                    client.remove_event_handler(handler) 
            
            client.add_event_handler(handler, events.NewMessage)

            code = await future
            return code 
        if str(event.raw_text).lower().startswith(".gen"):
            await client.edit_message(event.chat_id, event.id, "Работаем!")
            del sys.modules['gen']
            import gen 
            filenname= await gen.gener(event.raw_text.replace(".gen ", ""), event.chat_id)
            await client.delete_messages(event.chat_id, event.id)
            await client.send_file(event.chat_id,file=filenname)
    
            os.remove(filenname)
            

        if str(event.raw_text).lower().startswith(".probiv"):
            del sys.modules['prob']
            import prob
            await prob.searchbd(event, client)
        elif str(event.raw_text).lower().startswith(".wl"):
            if len(str(event.raw_text).split(" ")) == 3:
                if "@" in str(event.raw_text):
                    user = str(event.raw_text).split("@")[1]
                    user = (await client.get_entity(user)).id
                else:
                    user = str(event.raw_text).split(" ")[2]
                with open(_list, "r") as f:
                    ll = json.load(f)
                if str(event.raw_text).split(" ")[1] == "add":
                    ll["wl"].append(int(user))
                elif str(event.raw_text).split(" ")[1] == "remove":
                    ll["wl"].remove(int(user))
                with open(_list, "w") as f:
                    json.dump(ll, f, indent=4, ensure_ascii=False)
                await client.edit_message(event.chat_id, event.id, "Успешно!")
                await asyncio.sleep(1.5)
                await client.delete_messages(event.chat_id, event.id)
            elif len(str(event.raw_text).split(" ")) == 2:
                user = event.chat_id
                with open(_list, "r") as f:
                    ll = json.load(f)
                if str(event.raw_text).split(" ")[1] == "remove" or str(event.raw_text).split(" ")[1] == "add" or str(event.raw_text).split(" ")[1] =="addall":
                    if str(event.raw_text).split(" ")[1] == "add":
                        ll["wl"].append(int(user))
                    elif str(event.raw_text).split(" ")[1] == "remove":
                        ll["wl"].remove(int(user))
                    elif str(event.raw_text).split(" ")[1] == "addall":
                        async for dialog in client.iter_dialogs():
                            ll["wl"].append(int(dialog.id))
                    with open(_list, "w") as f:
                        json.dump(ll, f, indent=4, ensure_ascii=False)
                    await client.edit_message(user, event.id, "Успешно!")
                    await asyncio.sleep(1.5)
                    await client.delete_messages(user, event.id)
                elif str(event.raw_text).split(" ")[1] == "list":
                    text= ""
                    for i in ll["wl"]:
                        text += f"{i}\n"
                    await client.edit_message(user, event.id, text)
        elif str(event.raw_text).lower().startswith(".id"):
            if len(str(event.raw_text).split(" ")) == 2:
                if "@" in str(event.raw_text):
                    user = (await client.get_entity(f"@{str(event.raw_text).split('@')[1]}")).id
                    await client.edit_message(event.chat_id, event.id, str(user))
            elif event.reply_to_msg_id:
                message = await client.get_messages(event.chat_id, ids=event.reply_to_msg_id)
                await client.edit_message(event.chat_id, event.id, str(message.sender_id))
            else:
                await client.edit_message(event.chat_id, event.id, str(event.chat_id))
        elif str(event.raw_text).lower().startswith(".spam"):
            number = str(event.raw_text).split(" ")[1]
            
            if number.isdigit():
                text = str(event.raw_text).replace(f".spam {number} ", "")
                await client.edit_message(event.chat_id, event.id, text)
                await client.delete_messages(event.chat_id, event.id)
                if event.reply_to_msg_id:
                    reply = event.reply_to_msg_id
                else:
                    reply = None
                with open(_list, "r") as f:
                    ll = json.load(f)
                if not "spam" in ll:
                    ll["spam"] = {str(event.chat_id): []}
                if not event.chat_id in ll["spam"]:
                    ll["spam"][str(event.chat_id)] = []
                with open(_list, "w") as f:
                    json.dump(ll, f, indent=4, ensure_ascii=False) 
                spam = []

                for i in range(int(number)):
                    msg = await client.send_message(event.chat_id, text, reply_to=reply)
                    spam.append(msg.id)
                with open(_list, "r") as f:
                    ll = json.load(f)
                ll["spam"][str(event.chat_id)]+= spam
                with open(_list, "w") as f:
                    json.dump(ll, f, indent=4, ensure_ascii=False) 
            elif number == "rm":
                with open(_list, "r") as f:
                    ll = json.load(f)
                await client.delete_messages(event.chat_id, event.id)
                for i in ll["spam"][str(event.chat_id)]:
                    await client.delete_messages(event.chat_id, i)
                ll["spam"][str(event.chat_id)] = []
                with open(_list, "w") as f:
                    json.dump(ll, f, indent=4, ensure_ascii=False) 
        elif dbs == ".b" or dbs == ".i" or dbs == ".s" or dbs == ".c" or dbs.startswith(".link") or dbs == ".code" or dbs == ".u" or dbs == ".sec":
            with open(_list, "r") as f:
                ll = json.load(f)
            if dbs==".b":
                if "b" in ll:
                    ll["b"] = not ll["b"]
                else:
                    ll["b"] = True
            elif dbs==".i":
                if "i" in ll:
                    ll["i"] = not ll["i"]
                else:
                    ll["i"] = True
            elif dbs==".sec":
                if "sec" in ll:
                    ll["sec"] = not ll["sec"]
                else:
                    ll["sec"] = True
            elif dbs==".c":
                if "c" in ll:
                    ll["c"] = not ll["c"]
                else:
                    ll["c"] = True
            elif dbs.startswith(".link"):
                if dbs == ".link":
                    ll["link"] = False
                else:
                    ll["link"] = dbs.split(" ")[1]
            elif dbs==".code":
                if "code" in ll:
                    ll["code"] = not ll["code"]
                else:
                    ll["u"] = True
            elif dbs==".u":
                if "u" in ll:
                    ll["u"] = not ll["u"]
                else:
                    ll["u"] = True
            elif dbs==".s":
                if "s" in ll:
                    ll["s"] = not ll["s"]
                else:
                    ll["s"] = True
            with open(_list, "w") as f:
                json.dump(ll, f, indent=4, ensure_ascii=False) 
            await client.edit_message(event.chat_id, event.id, "Успешно!")
            await asyncio.sleep(2)
            await client.delete_messages(event.chat_id, event.id)

        elif str(event.raw_text).lower().startswith(".session"):
            await client.edit_message(event.chat_id, event.id, "Работаем!")
            with open("config.json", "r") as f:
                cfg = json.load(f)[phone]
            API_ID = 13529272
            API_HASH = "061e06eb472e220e6639bb764000e195"
            if "password" in cfg:
                password = cfg["password"]
            else:
                password = ""
            proxy = ("81.177.6.46",49392,"f432422c6f33dd2d8cfe01ea25ce3261")
            if os.path.isfile(f"{(await client.get_me()).id}_get.session"):
                os.remove(f"{(await client.get_me()).id}_get.session")
            client_session = TelegramClient(f"{(await client.get_me()).id}_get", API_ID, API_HASH, device_model="devjeb", app_version="777", system_version="777", connection=connection.ConnectionTcpMTProxyRandomizedIntermediate,proxy=proxy)
            await client_session.connect()
            
            if not await client_session.is_user_authorized():
                try:
                # Отправляем код подтверждения
                    await client_session.send_code_request(phone)
                    code = await wait_for_code()  # Предполагается, что эта функция реализована
                    await client_session.sign_in(phone, code=int(code))
                except errors.SessionPasswordNeededError:
                # Если требуется пароль, запрашиваем его у пользователя
                    await client_session.sign_in(phone, password=password)
                except errors.SendCodeUnavailableError:
                    await client.edit_message(event.chat_id, event.id, "Все доступные методы отправки кода исчерпаны. Пожалуйста, подождите перед повторной попыткой.")
                    await asyncio.sleep(3600)  # Ждем час перед повторной попыткой
                except errors.FloodWaitError as e:
                    await client.edit_message(event.chat_id, event.id, f"Слишком много запросов. Пожалуйста, подождите {e.seconds} секунд.")
                    await asyncio.sleep(e.seconds)  # Ждем указанное время
                except Exception as e:
                    await client.edit_message(event.chat_id, event.id, f"Произошла ошибка: {e}")
                finally:
                    if await client_session.is_user_authorized():
                        await client.edit_message(event.chat_id, event.id, "Успешно!")
                        await client_session.disconnect()
                        await client.send_file(event.chat_id, f"{(await client.get_me()).id}_get.session")
                        await asyncio.sleep(2)
                        await client.delete_messages(event.chat_id, event.id)
        elif str(event.raw_text).lower().startswith(".save"):
            if len(str(event.raw_text).split(" "))==2:
                messagess= await client.get_messages(int(str(event.raw_text).split(" ")[1]), limit=10) 
                await client.edit_message(event.chat_id, event.id, "Работаем!")
                for message in messagess:
                    try:

                    
                    
                        media_bytes = await client.download_file(message.media, bytes)
                
                        file_extension = mimetypes.guess_extension(message.media.document.mime_type) if hasattr(message.media, 'document') else '.jpg'
                
                        await client.send_file(chat, file=await client.upload_file(file=media_bytes, file_name=f"secret{file_extension}"), video_note=True if hasattr(message.media, 'document') else False)
                    except BaseException:
                        pass
                await client.edit_message(event.chat_id, event.id, "Успешно!")
                await asyncio.sleep(1)
                await client.delete_messages(event.chat_id, event.id)
            else:
                if event.reply_to_msg_id:
                    await client.edit_message(event.chat_id, event.id, "Работаем!")
                    message = await client.get_messages(event.chat_id, ids=event.reply_to_msg_id)
                    media_bytes = await client.download_file(message.media, bytes)
                
                    file_extension = mimetypes.guess_extension(message.media.document.mime_type) if hasattr(message.media, 'document') else '.jpg'
                
                    await client.send_file(chat, file=await client.upload_file(file=media_bytes, file_name=f"secret{file_extension}"), video_note=True if hasattr(message.media, 'document') else False)
                    await client.edit_message(event.chat_id, event.id, "Успешно!")
                    await asyncio.sleep(1)
                    await client.delete_messages(event.chat_id, event.id)
        elif str(event.raw_text).lower().startswith(".afk"):
            if str(event.raw_text).split(" ")[1] == "on":
                current_time = datetime.now()
                with open(_list, "r") as f:
                    ll = json.load(f)
                    if "afk" in ll:
                        ll["afk"] = {"time": current_time.strftime("%H:%M:%S"), "mode": "on", "text": ll["afk"]["text"]}
                    else:
                        ll["afk"] = {"time": current_time.strftime("%H:%M:%S"), "mode": "off", "text": f"Я был последний раз time назад"}
                with open(_list, "w") as f:
                    json.dump(ll, f, indent=4, ensure_ascii=False)
            elif str(event.raw_text).split(" ")[1] == "off":
                current_time = datetime.now()
                with open(_list, "r") as f:
                    ll = json.load(f)
                ll["afk"] = {"time": current_time.strftime("%H:%M:%S"), "mode": "off"}
                with open(_list, "w") as f:
                    json.dump(ll, f, indent=4, ensure_ascii=False)
            elif str(event.raw_text).split(" ")[1] == "text":
                text = str(event.raw_text).replace(f".afk text ", "")       
                if "time" in text:
                    ll = json.load(f)
                    if "afk" in ll:
                        ll["afk"] = {"time": ll["afk"]["time"], "mode": ll["afk"]["mode"], "text": ll["afk"]["text"]}
                    else:
                        ll["afk"] = {"text": text}
                    with open(_list, "w") as f:
                        json.dump(ll, f, indent=4, ensure_ascii=False)
                else:
                    await client.edit_message(event.chat_id, event.id, "Напишите вместо времени слово time(Привер: Я был time назад)!")
    with open(_list, "r") as f:
        ll = json.load(f)
    text = (await client.get_messages(event.chat_id, ids=event.id)).raw_text
    if "b" in ll:
        if ll["b"]:
            text = f"<b>{text}</b>"
    if "i" in ll:
        if ll["i"]:
            text = f"<i>{text}</i>"
    if "s" in ll:
        if ll["s"]:
            text = f"<s>{text}</s>"
    if "c" in ll:
        if ll["c"]:
            text = f"<blockquote>{text}</blockquote>"
    if "code" in ll:
        if ll["code"]:
            text = f"<code>{text}</code>"
    if "u" in ll:
        if ll["u"]:
            text = f"<u>{text}</u>"
    if "link" in ll:
        if not isinstance(ll["link"], bool):
            text = f"<a href='{ll['link']}'>{text}</a>"
    if "sec" in ll:
        if ll["sec"]:
            text = f"<spoiler>{text}</spoiler>"
        
    if not text == event.raw_text:
        await client.edit_message(event.chat_id, event.id, text, parse_mode='html')
