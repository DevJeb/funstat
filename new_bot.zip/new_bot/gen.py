import requests, asyncio,random
from g4f.client import Client
from urllib.parse import quote
# Запрашиваем у пользователя текстовое описание (промпт) для генерации изображения
proxies = {
    'http': 'socks5h://127.0.0.1:9050',  # 'socks5h' вместо 'socks5' для DNS через Tor
    'https': 'socks5h://127.0.0.1:9050'
}
async def gener(prompt, id):
# Создаём экземпляр клиента
    
    seed=random.randint(0, 10000000000000)
# Получаем URL сгенерированного изображения
    image_url = f"https://image.pollinations.ai/prompt/{quote(prompt, safe='')}?width=1024&height=1024&model=flux&nologo=true&private=false&enhance=false&safe=false&seed={seed}"
    print(image_url)
    suc= False
    while not suc:
        try:
            image_data = requests.get(image_url, proxies=proxies, timeout=10).content
            suc=True
        except requests.exceptions.RequestException as e:
            pass
# Сохраняем изображение
    with open(f"generated_image_{seed}.jpg", "wb") as file:
        file.write(image_data)
    print(f"generated_image_{seed}.jpg")
    return f"generated_image_{seed}.jpg"
