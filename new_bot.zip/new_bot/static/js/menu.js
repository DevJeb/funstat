// menu.js
document.addEventListener('DOMContentLoaded', function() {
    // Создаем элементы меню
    const menuHtml = `
        <div id="side-menu" class="side-menu">
            <div class="menu-header">
                <div class="burger-menu close" onclick="closeMenu()">
                    <div class="burger-line"></div>
                    <div class="burger-line"></div>
                    <div class="burger-line"></div>
                </div>
                <h3>Меню</h3>
            </div>
            <a href="/panel"><i class="menu-icon">📊</i> Главная</a>
            <a href="/"><i class="menu-icon">➕</i> Добавить номер</a>
            <a href="#" onclick="logout(); return false;"><i class="menu-icon">🚪</i> Выйти</a>
        </div>
        
        <div id="menu-overlay" class="menu-overlay" onclick="closeMenu()"></div>
        
        <div class="burger-menu" onclick="openMenu()">
            <div class="burger-line"></div>
            <div class="burger-line"></div>
            <div class="burger-line"></div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('afterbegin', menuHtml);
    
    const style = document.createElement('style');
    style.textContent = `
        .side-menu {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 1000;
            top: 0;
            left: 0;
            background-color: #1a1a1a;
            overflow-x: hidden;
            transition: 0.5s;
            box-shadow: 2px 0 10px rgba(0,0,0,0.5);
        }
        
        .side-menu a {
            padding: 12px 20px 12px 40px;
            text-decoration: none;
            font-size: 16px;
            color: #fff;
            display: block;
            transition: 0.3s;
            border-left: 4px solid transparent;
        }
        
        .side-menu a:hover {
            background-color: #2a2a2a;
            border-left: 4px solid #6e42e5;
        }
        
        .menu-icon {
            margin-right: 10px;
        }
        
        .burger-menu {
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1;
            cursor: pointer;
            padding: 10px;
            transition: 0.4s;
        }
        
        .burger-menu.close {
            position: absolute;
            top: 10px;
            left: 10px;
        }
        
        .burger-line {
            width: 25px;
            height: 3px;
            background-color: #fff;
            margin: 5px 0;
            transition: 0.4s;
        }
        
        .burger-menu.close .burger-line:nth-child(1) {
            transform: rotate(-45deg) translate(-5px, 6px);
        }
        
        .burger-menu.close .burger-line:nth-child(2) {
            opacity: 0;
        }
        
        .burger-menu.close .burger-line:nth-child(3) {
            transform: rotate(45deg) translate(-5px, -6px);
        }
        
        .menu-header {
            padding: 20px;
            border-bottom: 1px solid #333;
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .menu-header h3 {
            margin: 0 0 0 15px;
            color: #6e42e5;
        }
        
        .menu-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 0;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            opacity: 0;
            transition: opacity 0.5s, width 0s 0.5s;
        }
        
        body.menu-open {
            margin-left: 250px;
        }
        
        @media screen and (max-width: 768px) {
            body.menu-open {
                margin-left: 0;
            }
        }
    `;
    document.head.appendChild(style);
});

function openMenu() {
    document.getElementById("side-menu").style.width = "250px";
    document.getElementById("menu-overlay").style.width = "100%";
    document.getElementById("menu-overlay").style.opacity = "1";
    document.body.classList.add('menu-open');
}

function closeMenu() {
    document.getElementById("side-menu").style.width = "0";
    document.getElementById("menu-overlay").style.opacity = "0";
    document.body.classList.remove('menu-open');
    setTimeout(() => {
        document.getElementById("menu-overlay").style.width = "0";
    }, 500);
}