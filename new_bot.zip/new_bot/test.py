# from telethon import TelegramClient, errors, sessions
# import asyncio
# async def main():
#     client = TelegramClient(sessions.StringSession(), 13529272, "061e06eb472e220e6639bb764000e195")
#     await client.connect()
#     await client.send_code_request(phone="89371553776")
#     try:
#         await client.sign_in(phone="89371553776", code=input())
#     except errors.rpcerrorlist.SessionPasswordNeededError:
#         print("pass")
# asyncio.run(main()))