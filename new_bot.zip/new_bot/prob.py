import os
from telethon import TelegramClient, events
from telethon.tl.types import KeyboardButtonUrl
from telethon.errors import UserNotParticipantError
import logging
import asyncio  # Добавлен импорт asyncio
import requests
cod="""
<!DOCTYPE html>
<html lang="ru">
<head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>devjeb</title>
<style>
.card p{
white-space:pre-wrap;
word-wrap:break-word;
overflow-wrap:break-word;
margin-bottom:1rem;
line-height:1.8;
font-family:monospace;
color:#b2bec3;
padding:0.5rem;
background:rgba(255,255,255,0.05);
border-radius:5px;
}
.card h2{
margin-bottom:1.5rem;
padding-bottom:0.5rem;
border-bottom:2px solid #00b894;
}
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'SegoeUI',sans-serif;
}
body{
background:linear-gradient(135deg,#1a1a1a,#2d3436);
min-height:100vh;
color:#ffffff;
line-height:1.6;
padding:2rem;
overflow-x: hidden;
}
.container{
max-width:1200px;
margin:0 auto;
padding:2rem;
}
.header{
text-align:center;
margin-bottom:3rem;
}
h1{
font-size:3.5rem;
margin-bottom:1rem;
background:linear-gradient(45deg,#00b894,#00cec9);
-webkit-background-clip:text;
-webkit-text-fill-color:transparent;
text-shadow:0 0 15px rgba(0,184,148,0.3);
}
.card-container{
display:grid;
gap:2rem;
}
.card{
background:rgba(0,0,0,0.3);
padding:2rem;
border-radius:15px;
backdrop-filter:blur(10px);
border:1px solid rgba(255,255,255,0.1);
transition:transform 0.3s ease,box-shadow 0.3s ease;
}
.card:hover{
transform:translateY(-10px);
box-shadow:0 15px 30px rgba(0,0,0,0.4);
}
.button{
display:inline-block;
padding:1rem 2rem;
background:linear-gradient(45deg,#00b894,#00cec9);
color:white;
text-decoration:none;
border-radius:50px;
transition:transform 0.3s ease,box-shadow 0.3s ease;
border:none;
cursor:pointer;
font-size:1.1rem;
}
.button:hover{
transform:translateY(-3px);
box-shadow:05px 15px rgba(0,184,148,0.4);
}
@media(max-width:768px){
.container{
padding:1rem;
}
h1{
font-size:2.5rem;
}
.card p{
font-size:0.9rem;
}
}
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>devjeb</h1>
</div>
<div class="card-container">
"""
end="""
</div>
</div>
</body>
</html>
"""
def searchbds(id, search):
    data = {"token": "5696420520:OhuUt7Zq",
            "request": str(search), 
            'limit': 1000, 
            "lang": "ru"}
    url = 'https://leakosintapi.com/'
    response = requests.post(url, json=data)
    result=cod
    print(response.json())
    if 500 == response.status_code:
        return False
    else:
        if "No results found" in response.json()["List"]:
            return False
        for i in response.json()["List"]:
            result+="""
            <div class="card">
                <h2>"""+ str(i)+"</h2>\n<p>"
            for j in response.json()["List"][i]["Data"][0].keys():
                result+=str(j) + ": " + str(response.json()["List"][i]["Data"][0][j])+"\n"
            result+="</p></div>\n"
        result+=end
        with open(f"result_{id}.html", "w", encoding='utf-8') as f:
            f.write(result)
        return True
def search_bdsm(id, search):
    ses=requests.Session()
    ses.post("http://94.177.51.223:5693/token", data={"username":"devjeb","password":"devjeb_developer"})
    url = "http://94.177.51.223:5693/leak/search"

    headers = {

    "Origin": "http://94.177.51.223:12396",
    "Referer": "http://94.177.51.223:12396/"
    }

# Данные для отправки (JSON-объект)
    data = {
    "query": str(search)  # Пример значения, которое вы ищете
    }

# Отправляем POST-запрос
    response = ses.post(
    url,
    json=data,  # Автоматически сериализует данные в JSON
    headers=headers
    )

# Проверяем статус ответа


    if response.status_code == 200:
        results = response.json()
        if results["results"][0]=="База данных: No results found":
            return False
        result=cod
        for i in [i for i in [i.split("\n") for i in "\n".join([i for i in results["results"]]).split("База данных: ") if i] if i]:
            
            result+="""
            <div class="card">
                <h2>"""+ str(i[0])+"</h2>\n<p>"
            for j in i:
                if not j==i[0]:
                    result+=str(j)+"\n"
            result+="</p></div>\n"
        result+=end
        with open(f"result_{id}.html", "w", encoding='utf-8') as f:
            f.write(result)
        return True
def searchbds_vk(id, search):
    def ifnot(data, text):
        if text == "":
            return ""
        elif not text == "":
            return data+" "+text+"\n"
    vk_user_id = search
    params = {
        "access_token": "0af157510af157510af15751aa0a89e69600af10af157516a0bc15996e74fe2b440998c",
        "v": "5.131",
        "user_ids": vk_user_id,
        "fields": "first_name,last_name,status,sex,bdate,city,country,photo_max_orig,mobile_phone,home_phone,connections,site,about,activities,books,games,movies,music,tv,quotes,schools,universities,career,military,relation,personal"
    }

    try:
        response = requests.get("https://api.vk.com/method/users.get", params=params)
        response.raise_for_status()
        data = response.json()
    except requests.exceptions.RequestException as e:
        return False
    except ValueError as e:
        return False

    if "response" not in data or not data["response"]:
        return False
    res=cod.replace("<h1>devjeb</h1>", "<h1>devjeb</h1>\n<h1>VK</h1>")
    user = data["response"][0]
    res+="""<div class="card">
                <h2>Информация о профиле ВК</h2><p>"""
    if "deactivated" in user:
        res+="Этот профиль ВКонтакте удалён.</p></div>"+end
        with open(f"result_{id}.html", "w", encoding='utf-8') as f:
            f.write(res)
        return True

    first_name = user.get("first_name", "")
    last_name = user.get("last_name", "")
    status = user.get("status", "")
    sex = "Ж" if user.get("sex") == 1 else ("М" if user.get("sex") == 2 else "")
    bdate = user.get("bdate", "")
    city = user.get("city", {}).get("title", "")
    country = user.get("country", {}).get("title", "")
    photo_url = user.get("photo_max_orig", "")
    mobile_phone = user.get("mobile_phone", "")
    home_phone = user.get("home_phone", "")
    site = user.get("site", "")
    about = user.get("about", "")
    activities = user.get("activities", "")
    books = user.get("books", "")
    games = user.get("games", "")
    movies = user.get("movies", "")
    music = user.get("music", "")
    tv = user.get("tv", "")
    quotes = user.get("quotes", "")
    relation = user.get("relation", "")
    relation_map = {
        1: "Не женат/не замужем",
        2: "Есть друг/есть подруга",
        3: "Помолвлен/помолвлена",
        4: "Женат/замужем",
        5: "Всё сложно",
        6: "В активном поиске",
        7: "Влюблён/влюблена",
        8: "В гражданском браке"
    }
    relation = relation_map.get(relation, "")
    personal = user.get("personal", {})
    political = personal.get("political", "")
    political_map = {
        1: "Коммунистические",
        2: "Социалистические",
        3: "Умеренные",
        4: "Либеральные",
        5: "Консервативные",
        6: "Монархические",
        7: "Ультраконсервативные",
        8: "Индифферентные",
        9: "Либертарианские"
    }
    political = political_map.get(political, "")
    religion = personal.get("religion", "")
    inspired_by = personal.get("inspired_by", "")
    people_main = personal.get("people_main", "")
    people_main_map = {
        1: "Ум и креативность",
        2: "Доброта и честность",
        3: "Красота и здоровье",
        4: "Власть и богатство",
        5: "Смелость и упорство",
        6: "Юмор и жизнелюбие"
    }
    people_main = people_main_map.get(people_main, "")
    life_main = personal.get("life_main", "")
    life_main_map = {
        1: "Семейная жизнь",
        2: "Карьера и деньги",
        3: "Развлечения и отдых",
        4: "Наука и исследования",
        5: "Совершенствование мира",
        6: "Саморазвитие",
        7: "Красота и искусство",
        8: "Слава и влияние"
    }
    life_main = life_main_map.get(life_main, "")
    smoking = personal.get("smoking", "")
    smoking_map = {
        1: "Резко негативное",
        2: "Негативное",
        3: "Компромиссное",
        4: "Нейтральное",
        5: "Положительное"
    }
    smoking = smoking_map.get(smoking, "")
    alcohol = personal.get("alcohol", "")
    alcohol_map = {
        1: "Резко негативное",
        2: "Негативное",
        3: "Компромиссное",
        4: "Нейтральное",
        5: "Положительное"
    }
    alcohol = alcohol_map.get(alcohol, "")
    career = user.get("career", [])
    military = user.get("military", [])
    schools = user.get("schools", [])
    universities = user.get("universities", [])

    res+=ifnot("Имя:",first_name)
    res+=ifnot("Фамилия:", last_name)
    res+=ifnot("Статус:", status)
    res+=ifnot("Пол:", sex)
    res+=ifnot("Дата рождения:", bdate)
    res+=ifnot("Страна:", country)
    res+=ifnot("Город:", city)
    res+=ifnot("Мобильный телефон:", mobile_phone)
    res+=ifnot("Домашний телефон:", home_phone)
    res+=ifnot("Сайт:", site)
    res+=ifnot("О себе:", about)
    res+=ifnot("Интересы:", activities)
    res+=ifnot("Любимые книги:", books)
    res+=ifnot("Любимые игры:", games)
    res+=ifnot("Любимые фильмы:", movies)
    res+=ifnot("Любимая музыка:", music)
    res+=ifnot("Любимые телешоу:", tv)
    res+=ifnot("Любимые цитаты:", quotes)
    res+=ifnot("Семейное положение:", relation)
    res+=ifnot("Политические предпочтения:", political)
    res+=ifnot("Религия:", religion)
    res+=ifnot("Вдохновляется:", inspired_by)
    res+=ifnot("Главное в людях:", people_main)
    res+=ifnot("Главное в жизни:", life_main)
    res+=ifnot("Отношение к курению:", smoking)
    res+=ifnot("Отношение к алкоголю:", alcohol)
    if photo_url:
        res+=ifnot("Фотография:", photo_url)
    res+="</p></div>"
    if career:
        res+="""<div class="card">
                <h2>Карьера</h2><[]>"""
        for job in career:
            company = job.get("company", "")
            position = job.get("position", "")
            from_year = job.get("from", "")
            res+=ifnot("Компания:", company)
            res+=ifnot("Должность:", position)
            res+=ifnot("Год начала:", from_year)
        res+="</p></div>"

    if military:
        res+="""<div class="card">
                <h2>Военная служба</h2><p>"""
        for service in military:
            unit = service.get("unit", "")
            unit_id = service.get("unit_id", "")
            from_year = service.get("from", "")
            until_year = service.get("until", "")
            res+=ifnot("Отряд:", unit)
            res+=ifnot("ID отряда:", unit_id)
            res+=ifnot("Год начала:", from_year)
            res+=ifnot("Год окончания:", until_year)
        res+="</p></div>"
    if schools:
        res+="""<div class="card">
                <h2>Учебные заведения</h2><p>"""
        for school in schools:
            name = school.get("name", "")
            year_from = school.get("year_from", "")
            year_to = school.get("year_to", "")
            res+=ifnot("Название:", name)
            res+=ifnot("Год начала:", year_from)
            res+=ifnot("Год окончания:", year_to)
        res+="</p></div>"

    if universities:
        res+="""<div class="card">
                <h2>Университеты</h2><p>"""
        for university in universities:
            name = university.get("name", "")
            faculty = university.get("faculty_name", "")
            graduation = university.get("graduation", "")
            res+=ifnot("Название:" + name)
            res+=ifnot("Факультет:" + faculty)
            res+=ifnot("Год окончания:" + graduation)
        res+="</p></div>"
    res+=end
    with open(f"result_{id}.html", "w", encoding='utf-8') as f:
        f.write(res)
    return True
logging.basicConfig(format='[%(levelname)s] %(message)s', level=logging.INFO)

async def searchbd(event, client):
    await client.edit_message(event.chat_id, event.id, "Обрабатываем запрос")
    if event.text.lower().startswith(".probiv vk "):
        ress = searchbds_vk(event.sender_id, (event.raw_text).replace(".probiv vk ", ""))
    else:
        ress = searchbds(event.sender_id, (event.raw_text).replace(".probiv ", ""))
    await client.delete_messages(event.chat_id, event.id)
    logging.info(event.raw_text)
    if ress:
        await client.send_file(
                event.chat_id,
                file=f"result_{event.sender_id}.html"
            )
        os.remove(f"result_{event.sender_id}.html")
    else:
        pass
